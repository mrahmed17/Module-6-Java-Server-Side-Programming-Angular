# Navbar Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/uahnbu/pen/jOmMWYG](https://codepen.io/uahnbu/pen/jOmMWYG).

