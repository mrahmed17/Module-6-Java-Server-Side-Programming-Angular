# PayrollProject
## Overview
The Employee Management System, built using Angular and Spring Boot, efficiently handles employee data, attendance tracking, bonus computation, advance management, leave requests (with approval workflows), and salary processing. With its user-friendly interface and automated workflows, it streamlines HR tasks, demonstrating expertise in full-stack development.
