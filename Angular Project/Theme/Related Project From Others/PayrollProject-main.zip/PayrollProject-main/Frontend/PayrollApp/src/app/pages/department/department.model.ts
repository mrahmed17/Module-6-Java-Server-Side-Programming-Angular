export class DepartmentModel{
    id!: number;
    deptName?: string;
}