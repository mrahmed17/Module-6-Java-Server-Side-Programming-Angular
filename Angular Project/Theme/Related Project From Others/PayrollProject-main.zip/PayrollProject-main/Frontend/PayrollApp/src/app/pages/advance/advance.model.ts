export class Advance{
    id!:number;
    employee?: {
        name:string;
       // Details of the employee, such as name, ID, etc.
     };
     amount?: number;
     reason?: string;
     date?: string; 
}