export class Bonus {

    id!: number;
    amount?: number;
    bonusDate?: string;
    employee?: {
        id?: number;
        name?: string
    }

    
}


  