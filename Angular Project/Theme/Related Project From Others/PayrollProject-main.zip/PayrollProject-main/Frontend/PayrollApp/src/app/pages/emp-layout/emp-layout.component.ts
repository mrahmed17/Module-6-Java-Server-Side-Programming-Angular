import { Component } from '@angular/core';

@Component({
  selector: 'app-emp-layout',
  templateUrl: './emp-layout.component.html',
  styleUrl: './emp-layout.component.css'
})
export class EmpLayoutComponent {

}
