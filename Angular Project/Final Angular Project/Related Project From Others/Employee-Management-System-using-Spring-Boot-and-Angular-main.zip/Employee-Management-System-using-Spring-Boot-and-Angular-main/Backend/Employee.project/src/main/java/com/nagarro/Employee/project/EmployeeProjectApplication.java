package com.nagarro.Employee.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.nagarro.Employee.project.EmployeeProjectApplication;

@SpringBootApplication
public class EmployeeProjectApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(EmployeeProjectApplication.class, args);
	}

}
