import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-slips',
  templateUrl: './pay-slips.component.html',
  styleUrls: ['./pay-slips.component.scss']
})
export class PaySlipsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
