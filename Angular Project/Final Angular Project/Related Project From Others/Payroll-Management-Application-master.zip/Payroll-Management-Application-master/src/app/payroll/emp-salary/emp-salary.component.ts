import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-salary',
  templateUrl: './emp-salary.component.html',
  styleUrls: ['./emp-salary.component.scss']
})
export class EmpSalaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
