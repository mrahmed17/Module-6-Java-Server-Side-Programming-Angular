export class User {
  user_id: number;
  user_sal: string;
  user_first_name: string;
  user_middle_name: string;
  user_last_name: string;
  user_gender: string;
  user_address: string;
  user_city: string;
  user_province: string;
  user_country: string;
  user_mobile: string;
  user_email: string;
  user_status: string;
  user_department: string;
  user_dob: string;
  user_nationalty: string;
}