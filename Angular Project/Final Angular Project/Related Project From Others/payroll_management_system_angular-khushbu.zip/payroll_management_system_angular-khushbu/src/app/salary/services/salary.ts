export class Salary {
  salary_id: number;
  salary_employee_id: string;
  salary_working_days: string;
  salary_basic: string;
  salary_dtax: string;
  salary_desc: string;
  salary_month: string;
  salary_total: string;
  salary_dedc: string;
}