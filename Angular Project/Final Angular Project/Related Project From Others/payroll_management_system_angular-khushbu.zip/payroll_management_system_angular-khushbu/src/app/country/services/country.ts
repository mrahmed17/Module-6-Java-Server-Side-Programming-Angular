export class Country {
  id: number;
  firstName: string;
  lastName: string;
  emailId: string;
  active: boolean;
}
