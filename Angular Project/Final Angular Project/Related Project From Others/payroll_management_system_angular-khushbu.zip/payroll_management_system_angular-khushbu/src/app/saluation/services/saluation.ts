export class Saluation {
  id: number;
  firstName: string;
  lastName: string;
  emailId: string;
  active: boolean;
}
