export class Employee {
  employee_id: number;
  employee_sal: string;
  employee_first_name: string;
  employee_middle_name: string;
  employee_last_name: string;
  employee_gender: string;
  employee_address: string;
  employee_city: string;
  employee_province: string;
  employee_country: string;
  employee_mobile: string;
  employee_email: string;
  employee_status: string;
  employee_department: string;
  employee_dob: string;
  employee_nationalty: string;
}