export class Department {
  department_id: number;
  department_name: string;
}
