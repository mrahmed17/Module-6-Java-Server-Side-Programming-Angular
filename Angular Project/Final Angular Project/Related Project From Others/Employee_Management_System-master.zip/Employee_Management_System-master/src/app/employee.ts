export class Employee {
    id !: number;
    firstname !: string;
    lastname !: string;
    emailId !: string;
}
